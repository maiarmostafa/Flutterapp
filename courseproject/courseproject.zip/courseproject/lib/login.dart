import 'package:flutter/material.dart';
import 'container.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  
  String email;
  String password;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        iconTheme: IconThemeData(color: Color(0xFF2372A3)),
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
                child: Hero(
                    tag: 'Logo',
                    child: Circeleavatarimage(
                      radius: 100,
                    ))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
              child: TextField(
                onChanged: (value){
                  email=value;
                },
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(hintText: 'Enter Your Email'),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
              child: TextField(
                obscureText: true,
                onChanged: (value){
                  password=value;
                },
                decoration: InputDecoration(hintText: 'Enter Your Password'),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Row(
              children: <Widget>[
                SizedBox(
                  width: 85,
                ),
                RaisedButton(
                  color: Color(0xFF2372A3),
                  textColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(9.0)),
                  onPressed: () {
                    
                  },
                  child: Text(
                    'Login',
                    style: KTextstyle,
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Flatbuttonss(label: 'Forget Password?')
              ],
            ),
            SizedBox(
              height: 75,
            ),
            Expanded(
              child: Flatbuttonss(
                label: 'CREAT NEW ACCOUNT?',
                style: FontWeight.bold,
                onpressed: () {
                  Navigator.pushNamed(context, '/Regester');
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
