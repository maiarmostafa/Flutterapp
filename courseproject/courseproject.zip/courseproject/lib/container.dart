import 'package:flutter/material.dart';

const KTextstyle = TextStyle(color: Colors.white, fontSize: 20);

class Flatbuttonss extends StatelessWidget {
  const Flatbuttonss({this.label, this.style, this.onpressed});
  final String label;
  final FontWeight style;
  final Function onpressed;
  @override
  Widget build(BuildContext context) {
    return FlatButton(
      textColor: Color(0xFF2372A3),
      onPressed: onpressed,
      child: Text(
        label,
        style: TextStyle(fontSize: 15, fontWeight: style),
      ),
    );
  }
}

class Circeleavatarimage extends StatelessWidget {
  const Circeleavatarimage({this.radius});
  final double radius;
  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundImage: AssetImage('images/clipeducation.png'),
      backgroundColor: Colors.transparent,
    );
  }
}

class Rowbuttons extends StatelessWidget {
  const Rowbuttons({this.colorr, this.textt,this.onpressed});
  final Color colorr;
  final Widget textt;
  final Function onpressed;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: RaisedButton(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(9.0)),
              color: colorr,
              onPressed: onpressed,
              child: textt,
            ),
          ),
        )
      ],
    );
  }
}
