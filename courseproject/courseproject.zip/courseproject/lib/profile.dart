import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Profilepage extends StatefulWidget {
  @override
  _ProfilepageState createState() => _ProfilepageState();
}

class _ProfilepageState extends State<Profilepage> {
  final _auth=FirebaseAuth.instance;
  FirebaseUser loggeduser;

  void getCurrentuser() async{
    try{
      final user=await _auth.currentUser();
      if(user!=null)
      {
        loggeduser=user;
        print(loggeduser.email);
      }
    }
    catch(e){
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}